/* 
	Using & instead of &&
	Sometimes, it doesn't matter
*/ 

#include <stdlib.h>
#include <stdio.h>

void foo(int n){ 
	int somedata[n]; 
	somedata[0] = 42; 
	printf("array size is %d\nFirst element is %d\n", n, somedata[0]);
}

int main(){

	int data[]; 
	
	foo(3); 
			
	return EXIT_SUCCESS;
}

