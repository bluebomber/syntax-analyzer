/* 
	should trigger NoEffect.html
*/ 

#include <stdlib.h>
#include <stdio.h>

int foo(int n){
	return n*n*n;
}

int main(){
	printf("Using the mystery foo function...\n"); 
	foo(42); 
	printf("...done\n");
	return EXIT_SUCCESS;
}

