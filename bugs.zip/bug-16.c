/* 
	Should trigger NoNewline.html
	I think gcc might add the newline itself now so this is not so much a bug than a deprecated feature I guess
	let me know if your findings differ
*/

#include <stdlib.h>

int main(){
	
	return EXIT_SUCCESS;
} // there is no newline in the source file after this
