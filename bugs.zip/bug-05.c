/* 
	Using & instead of &&
	Sometimes, it doesn't matter
*/ 

#include <stdlib.h>
#include <stdio.h>

int main(){

	if( 0 && 1 ){ 
		printf("0 && 1 \t is \t true\n"); 
	}
	
	if( 0 & 1 ){ 
		printf("0 & 1 \t is \t true\n"); 
	}

	if( 0 || 1 ){ 
		printf("0 || 1 \t is \t true\n"); 
	}
	
	if( 0 | 1 ){ 
		printf("0 | 1 \t is \t true\n"); 
	}
		
	return EXIT_SUCCESS;
}

