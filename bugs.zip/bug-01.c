/* undeclared variable x should generate compiler error 
	& SyntaxAnalyzer.py should not run on something buggy
*/ 

int main(){
	int something = 42; 
	int * ptr; 
	if(x = 42) *ptr = 42; 
}

/*
Error!  Variable requested (x) not found in current scope!
Traceback (most recent call last):
  File "SyntaxAnalyzer.py", line 1228, in <module>
    for id,w in getWarnings(file_name):
  File "SyntaxAnalyzer.py", line 1218, in getWarnings
    s.visit(ast)
  File "/usr/local/lib/python2.7/dist-packages/pycparser/c_ast.py", line 119, in visit
    return visitor(node)
  File "SyntaxAnalyzer.py", line 1004, in visit_FileAST
    self.visit(child)
  File "/usr/local/lib/python2.7/dist-packages/pycparser/c_ast.py", line 119, in visit
    return visitor(node)
  File "SyntaxAnalyzer.py", line 1018, in visit_FuncDef
    self.generic_visit(node)
  File "SyntaxAnalyzer.py", line 806, in generic_visit
    self.visit(child)
  File "/usr/local/lib/python2.7/dist-packages/pycparser/c_ast.py", line 119, in visit
    return visitor(node)
  File "SyntaxAnalyzer.py", line 974, in visit_Compound
    self.visit(currentItem)
  File "/usr/local/lib/python2.7/dist-packages/pycparser/c_ast.py", line 119, in visit
    return visitor(node)
  File "SyntaxAnalyzer.py", line 1096, in visit_If
    self.generic_visit(node)
  File "SyntaxAnalyzer.py", line 806, in generic_visit
    self.visit(child)
  File "/usr/local/lib/python2.7/dist-packages/pycparser/c_ast.py", line 119, in visit
    return visitor(node)
  File "SyntaxAnalyzer.py", line 829, in visit_Assignment
    if self.scopeStack.get_variable_type(node.lvalue.name).is_parameter():
AttributeError: 'NoneType' object has no attribute 'is_parameter'
*/
