/* 
	This triggers a call stack dump
*/ 

#include <stdio.h>
#include <stdlib.h>

int main(){
	char * str = 'This should be a string literal'; 
	return EXIT_SUCCESS;
}
/*
Traceback (most recent call last):
File "/var/www/ned/analyzers/SyntaxAnalyzer.py", line 1232, in
 
for id,w in getWarnings(file_name):
 
File "/var/www/ned/analyzers/SyntaxAnalyzer.py", line 1209, in getWarnings
 
cpp_args='-I%s' %fakes_path)
 
File "/usr/local/lib/python2.7/dist-packages/pycparser/__init__.py", line 93, in parse_file
 
return parser.parse(text, filename)
 
File "/usr/local/lib/python2.7/dist-packages/pycparser/c_parser.py", line 124, in parse
 
return self.cparser.parse(text, lexer=self.clex, debug=debuglevel)
 
File "/usr/local/lib/python2.7/dist-packages/pycparser/ply/yacc.py", line 265, in parse
 
return self.parseopt_notrack(input,lexer,debug,tracking,tokenfunc)
 
File "/usr/local/lib/python2.7/dist-packages/pycparser/ply/yacc.py", line 921, in parseopt_notrack
 
lookahead = get_token() # Get the next token
 
File "/usr/local/lib/python2.7/dist-packages/pycparser/c_lexer.py", line 68, in token
 
g = self.lexer.token()
 
File "/usr/local/lib/python2.7/dist-packages/pycparser/ply/lex.py", line 348, in token
 
newtok = func(tok)
 
File "/usr/local/lib/python2.7/dist-packages/pycparser/c_lexer.py", line 426, in t_BAD_CHAR_CONST
 
self._error(msg, t)
 
File "/usr/local/lib/python2.7/dist-packages/pycparser/c_lexer.py", line 84, in _error
 
self.error_func(msg, location[0], location[1])
 
File "/usr/local/lib/python2.7/dist-packages/pycparser/c_parser.py", line 147, in _lex_error_func
 
self._parse_error(msg, self._coord(line, column))
 
File "/usr/local/lib/python2.7/dist-packages/pycparser/plyparser.py", line 54, in _parse_error
 
raise ParseError("%s: %s" % (coord, msg))
 
pycparser.plyparser.ParseError: single-quote-string-1.c:9:15: Invalid char constant 'This should be a string literal'
*/
